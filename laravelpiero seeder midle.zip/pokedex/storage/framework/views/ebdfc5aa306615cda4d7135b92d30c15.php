<h2>Listado de Pokémon</h2>

    <a href="<?php echo e(route('pokemons.create')); ?>" class="btn btn-primary">Nuevo Pokémon</a>

   
    <div class="row">
    <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($pokemon->nombre); ?></h5>
                    <p class="card-text">
                        <strong>ID:</strong> <?php echo e($pokemon->id); ?><br>
                        <strong>Tipo:</strong> <?php echo e($pokemon->tipo); ?><br>
                        <strong>Tamaño:</strong> <?php echo e($pokemon->tamaño); ?><br>
                        <strong>Peso:</strong> <?php echo e($pokemon->peso); ?><br>
                        <td>
                        <a href="<?php echo e(route('pokemons.show', $pokemon->id)); ?>" class="btn btn-info">Ver</a>
                        <a href="<?php echo e(route('pokemons.edit', $pokemon->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('pokemons.destroy', $pokemon->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
</form>
                        </td>
                    </p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\pokedex\resources\views/pokemons/index.blade.php ENDPATH**/ ?>