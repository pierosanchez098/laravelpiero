
<?php $__env->startSection('content'); ?>
    <h2>Listado de Pokémon</h2>

    <a href="<?php echo e(route('pokemons.create')); ?>" class="btn btn-primary">Nuevo Pokémon</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Tipo</th>
                <th>Tamaño</th>
                <th>Peso</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pokemon->id); ?></td>
                    <td><?php echo e($pokemon->nombre); ?></td>
                    <td><?php echo e($pokemon->tipo); ?></td>
                    <td><?php echo e($pokemon->tamaño); ?></td>
                    <td><?php echo e($pokemon->peso); ?></td>
                    <td>
                        <a href="<?php echo e(route('pokemons.show', $pokemon->id)); ?>" class="btn btn-info">Ver</a>
                        <a href="<?php echo e(route('pokemons.edit', $pokemon->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('pokemons.destroy', $pokemon->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pokedex\resources\views/pokemons/index.blade.php ENDPATH**/ ?>