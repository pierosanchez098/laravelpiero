
<?php $__env->startSection('content'); ?>
    <h2>Detalles del Pokémon</h2>

    <p><strong>ID:</strong> <?php echo e($pokemon->id); ?></p>
    <p><strong>Nombre:</strong> <?php echo e($pokemon->nombre); ?></p>
    <p><strong>Tipo:</strong> <?php echo e($pokemon->tipo); ?></p>
    <p><strong>Tamaño:</strong> <?php echo e($pokemon->tamaño); ?></p>
    <p><strong>Peso:</strong> <?php echo e($pokemon->peso); ?></p>

    <a href="<?php echo e(route('pokemons.index')); ?>" class="btn btn-primary">Volver al listado</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pokedex\resources\views/pokemons/show.blade.php ENDPATH**/ ?>