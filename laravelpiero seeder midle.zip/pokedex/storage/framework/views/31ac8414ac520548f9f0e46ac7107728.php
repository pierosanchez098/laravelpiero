<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roles</title>
</head>
<body>
    <h2>Elige tu rol</h2>
    
    <form action="<?php echo e(route('set.role')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="role">Rol:</label>
        <select name="role" id="role">
            <option value="admin">Administrador</option>
            <option value="user">Usuario</option>
        </select>
        <button type="submit">Entrar</button>
    </form>
    
</body>
</html><?php /**PATH C:\pokedex\resources\views/choose_role.blade.php ENDPATH**/ ?>