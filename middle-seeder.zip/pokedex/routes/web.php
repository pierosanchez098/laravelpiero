

<?php

use App\Http\Controllers\PokemonController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoleController;

Route::get('/pokemons/index', [PokemonController::class, 'index'])->name('pokemons.index');
Route::get('/pokemons/indexusuario', [PokemonController::class, 'indexusuario'])->name('pokemons.indexusuario');
Route::get('/pokemons/create', [PokemonController::class, 'create'])->name('pokemons.create');
Route::post('/pokemons', [PokemonController::class, 'store'])->name('pokemons.store'); 

Route::get('/choose-role', [RoleController::class, 'chooseRole'])->name('choose.role');
Route::post('/set-role', [RoleController::class, 'setRole'])->name('set.role');

Route::middleware(['role:admin'])->group(function () {
    Route::resource('pokemons', PokemonController::class);
});

