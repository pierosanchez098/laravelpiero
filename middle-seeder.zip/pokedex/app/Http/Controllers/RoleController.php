<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RoleController extends Controller
{

    public function chooseRole()
    {
        return view('/pokemons/choose_role');
    }

    public function setRole(Request $request)
{
    $role = $request->input('role');

    $request->session()->put('role', $role);

    if ($role === 'admin') {
        return redirect('/pokemons/index'); 
    } else {
        return redirect('/pokemons/indexusuario'); 
    }
}
}
