

<?php $__env->startSection('content'); ?>
    <h2>Nuevo Pokémon</h2>

    <form action="<?php echo e(route('pokemons.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="agua">Agua</option>
            <option value="fuego">Fuego</option>
            <!-- Agrega más tipos según sea necesario -->
        </select>

        <label for="tamaño">Tamaño:</label>
        <select name="tamaño" required>
            <option value="grande">Grande</option>
            <option value="mediano">Mediano</option>
            <option value="pequeño">Pequeño</option>
        </select>

        <label for="peso">Peso:</label>
        <input type="number" name="peso" step="0.01" required>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pokedex\resources\views/pokemons/create.blade.php ENDPATH**/ ?>