<h2>Listado de Pokémon</h2>

   
    <div class="row">
    <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($pokemon->nombre); ?></h5>
                    <p class="card-text">
                        <strong>ID:</strong> <?php echo e($pokemon->id); ?><br>
                        <strong>Tipo:</strong> <?php echo e($pokemon->tipo); ?><br>
                        <strong>Tamaño:</strong> <?php echo e($pokemon->tamaño); ?><br>
                        <strong>Peso:</strong> <?php echo e($pokemon->peso); ?><br>
                        <td>
</form>
                        </td>
                    </p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH I:\pokedex\resources\views/pokemons/indexusuario.blade.php ENDPATH**/ ?>