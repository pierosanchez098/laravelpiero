<h2>Detalles del Pokémon</h2>

    <p><strong>ID:</strong> <?php echo e($pokemon->id); ?></p>
    <p><strong>Nombre:</strong> <?php echo e($pokemon->nombre); ?></p>
    <p><strong>Tipo:</strong> <?php echo e($pokemon->tipo); ?></p>
    <p><strong>Tamaño:</strong> <?php echo e($pokemon->tamaño); ?></p>
    <p><strong>Peso:</strong> <?php echo e($pokemon->peso); ?></p>

    <a href="<?php echo e(route('pokemons.index')); ?>" class="btn btn-primary">Volver al listado</a>
<?php /**PATH D:\pokedex2\resources\views/pokemons/show.blade.php ENDPATH**/ ?>