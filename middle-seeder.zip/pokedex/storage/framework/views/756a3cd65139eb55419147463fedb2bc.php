

<?php $__env->startSection('content'); ?>
    <h2>Editar Pokémon</h2>

    <form action="<?php echo e(route('pokemons.update', $pokemon->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" value="<?php echo e($pokemon->nombre); ?>" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="agua" <?php echo e($pokemon->tipo == 'agua' ? 'selected' : ''); ?>>Agua</option>
            <option value="fuego" <?php echo e($pokemon->tipo == 'fuego' ? 'selected' : ''); ?>>Fuego</option>
            <option value="planta" <?php echo e($pokemon->tipo == 'planta' ? 'selected' : ''); ?>>Planta</option>
            <option value="hada" <?php echo e($pokemon->tipo == 'hada' ? 'selected' : ''); ?>>Hada</option>
            <option value="lucha" <?php echo e($pokemon->tipo == 'lucha' ? 'selected' : ''); ?>>Lucha</option>
            <option value="normal" <?php echo e($pokemon->tipo == 'normal' ? 'selected' : ''); ?>>Normal</option>
            <option value="psiquico" <?php echo e($pokemon->tipo == 'psiquico' ? 'selected' : ''); ?>>Psiquico</option>
            <option value="siniestro" <?php echo e($pokemon->tipo == 'siniestro' ? 'selected' : ''); ?>>Siniestro</option>
            <option value="acero" <?php echo e($pokemon->tipo == 'acero' ? 'selected' : ''); ?>>Acero</option>
            <option value="tierra" <?php echo e($pokemon->tipo == 'tierra' ? 'selected' : ''); ?>>Tierra</option>
            <option value="roca" <?php echo e($pokemon->tipo == 'roca' ? 'selected' : ''); ?>>Roca</option>
            <option value="volador" <?php echo e($pokemon->tipo == 'volador' ? 'selected' : ''); ?>>Volador</option>
            <option value="insecto" <?php echo e($pokemon->tipo == 'insecto' ? 'selected' : ''); ?>>Insecto</option>
            <option value="hielo" <?php echo e($pokemon->tipo == 'hielo' ? 'selected' : ''); ?>>Hielo</option>
        </select>

        <label for="tamaño">Tamaño:</label>
        <select name="tamaño" required>
            <option value="grande" <?php echo e($pokemon->tamaño == 'grande' ? 'selected' : ''); ?>>Grande</option>
            <option value="mediano" <?php echo e($pokemon->tamaño == 'mediano' ? 'selected' : ''); ?>>Mediano</option>
            <option value="pequeño" <?php echo e($pokemon->tamaño == 'pequeño' ? 'selected' : ''); ?>>Pequeño</option>
        </select>

        <label for="peso">Peso:</label>
        <input type="number" name="peso" step="0.01" value="<?php echo e($pokemon->peso); ?>" required>

        <button type="submit" class="btn btn-primary">Guardar cambios</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pokedex\resources\views/pokemons/edit.blade.php ENDPATH**/ ?>